import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TaskDetailsComponent } from './task-details/task-details.component';
import { TaskListComponent } from './task-list/task-list.component';
import { PageNotFoudComponent } from './page-not-foud/page-not-foud.component';
import { EditTaskComponent } from './edit-task/edit-task.component';
const routes: Routes = [
  {path: '', redirectTo: '/view', pathMatch: 'full'},
  {path: 'add',component: TaskDetailsComponent},
  {path: 'view', component: TaskListComponent},
  {path: 'edit/:id', component: EditTaskComponent},
  {path: '**', component: PageNotFoudComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents =[TaskListComponent, 
                                 TaskDetailsComponent,
                                 PageNotFoudComponent,
                                 EditTaskComponent]
