import { Component, OnInit } from '@angular/core';
import { TaskManagerService } from 'src/app/task-manager.service';

@Component({
  selector: 'app-task-details',
  templateUrl: './task-details.component.html',
  styleUrls: ['./task-details.component.css']
})
export class TaskDetailsComponent implements OnInit {

  constructor(private _taskManagerService: TaskManagerService) { }

  ngOnInit() {
  }

}
