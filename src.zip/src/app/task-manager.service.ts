import { Injectable } from '@angular/core';
import { HttpClient , HttpHeaders} from '@angular/common/http';
import { ITask } from 'src/app/task';
import { Observable } from "rxjs";
import { catchError, map } from 'rxjs/operators';
import { FormGroup, FormControl } from '@angular/forms';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*'})
}
@Injectable({
  providedIn: 'root'
})

export class TaskManagerService {

  private _url = "http://localhost:8081/casestudy/";
  //http://localhost:8081/casestudy/view/1
  constructor(private http: HttpClient) { }
  form: FormGroup = new FormGroup({
    $key: new FormControl(),
    title: new FormControl(''),
    priority: new FormControl(''),
    startDate: new FormControl('')
  })

  getTaskList(): Observable<ITask[]> {
    return this.http.get<ITask[]>(this._url + "alltasks")
      .pipe(map(data => {
        return data;
      }),
      // "catchError" instead "catch"
      catchError(error => {
        return Observable.throw('Something went wrong ;)');
      })
      );
  }

  getTask(id: number): Observable<ITask> {
    return this.http.get<ITask>(this._url + "view/" + id);
  }

  updateTask(task){
    let body= JSON.stringify(task);
    return this.http.post(this._url + "edit/"+task.taskId,body,httpOptions);
  }
}
