import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { ReactiveFormsModule }from "@angular/forms";

import { AppRoutingModule , routingComponents} from './app-routing.module';
import { AppComponent } from './app.component';
import { TaskManagerService } from './task-manager.service';
import { HttpClientModule } from '@angular/common/http';
import { PageNotFoudComponent } from './page-not-foud/page-not-foud.component';
import { MyFilterPipe } from './my-filter.pipe';
import { EditTaskComponent } from './edit-task/edit-task.component';

@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    PageNotFoudComponent,
    MyFilterPipe,
    EditTaskComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [TaskManagerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
