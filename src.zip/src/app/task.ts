export interface ITask {
        taskId: number,
        endDate: string,
        priority: number,
        startDate: string,
        status: string,
        title: string,
        parentTaskId: 1,
        parentTask: ITask
}