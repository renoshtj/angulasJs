import { Component, OnInit } from '@angular/core';
import { TaskManagerService } from 'src/app/task-manager.service';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
filterargs = {taskId:'',
  endDate:'',
  priority:'',
  startDate:'',
  status:'',
  title:'',
  parentTaskId:''};
public tasks =[];

  constructor(private _taskManagerService: TaskManagerService) { }

  ngOnInit() {
    this._taskManagerService.getTaskList()
    .subscribe(data => this.tasks = data);
  }

}
