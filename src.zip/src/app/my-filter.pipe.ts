import { Pipe, PipeTransform } from '@angular/core';
import { ITask } from 'src/app/task';

@Pipe({
  name: 'myFilter',
  pure: false
})
export class MyFilterPipe implements PipeTransform {
  transform(tasks: ITask[], searchTermTask: string ) {
    if(searchTermTask===undefined || searchTermTask==''){
        return tasks;
    }
    return tasks.filter(task =>
     task.title.indexOf(searchTermTask) !=-1);
  }
}
