import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-not-foud',
  templateUrl: './page-not-foud.component.html',
  styleUrls: ['./page-not-foud.component.css']
})
export class PageNotFoudComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
