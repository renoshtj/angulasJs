import { Component, OnInit } from '@angular/core';
import { TaskManagerService } from 'src/app/task-manager.service';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {
  validMessage : string= "";
  taskeditform: FormGroup;
  public taskedit;
  constructor(private _taskManagerService: TaskManagerService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.taskeditform = new FormGroup({
      taskId: new FormControl(),
      priority: new FormControl('', Validators.required),
      endDate: new FormControl(),
      startDate: new FormControl(),
      status: new FormControl(),
      title: new FormControl('', Validators.required),
      parentTaskId: new FormControl()
    });
    this.getTaskedit(this.route.snapshot.params.id);
  }
  getTaskedit(id: number) {
    var _that = this;
    this._taskManagerService.getTask(id).subscribe(
      data => {
        _that.taskedit= data
        this.populateView()
      },
      err => console.error(err),
      () => console.log('Task Loaded for Editing'));
  }
  populateView(){
    this.taskeditform.controls['taskId'].setValue(this.taskedit.taskId);
    this.taskeditform.controls['priority'].setValue(this.taskedit.priority);
    this.taskeditform.controls['endDate'].setValue(this.taskedit.endDate);
    this.taskeditform.controls['startDate'].setValue(this.taskedit.startDate);
    this.taskeditform.controls['status'].setValue(this.taskedit.status);
    this.taskeditform.controls['title'].setValue(this.taskedit.title);
    this.taskeditform.controls['parentTaskId'].setValue(this.taskedit.parentTaskId);
    console.log(this.taskeditform);
  }
  updateTask(){
    console.log(this.taskeditform);

      this.validMessage ="Update Success";
      this._taskManagerService.updateTask(this.taskeditform.value).subscribe(
        data => {
          this.taskeditform.reset();
          return true;
        },
        error => {
          return Observable.throw(error);
        }
      )

  }
} 
